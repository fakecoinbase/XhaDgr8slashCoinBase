<footer class="container-fluid py-5 grad">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <p class="font-weight-bold text-white">
                    TRUSTED BY COMPANIES
                </p>
                <div class="row">
                    <?php for($i = 0; $i < 9; $i++): ?>
                    <div class="col-4 mb-2">
                        <div class="rounded-lg bg-light p-3"> <p>Company</p></div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
            <div class="col-md-3 offset-1 text-white">
                <p class="font-weight-bold text-white mb-2">
                    LEGAL
                </p>
                <p>Terms and Conditions</p>
                <p>Privacy policy</p>
                <p>Refund policy & risk disclosure</p>
            </div>
            <div class="col-md-3 text-white">
                <p class="font-weight-bold text-white mb-2">
                    PAGES
                </p>
                <p>Login</p>
                <p>Register</p>
                <p>FAQ</p>
                <p>Contact us</p>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\xampp\htdocs\CoinBase\resources\views/inc/footer.blade.php ENDPATH**/ ?>