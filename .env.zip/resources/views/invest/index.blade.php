@extends('layouts.app')

@section('content')
    invest.index template
@endsection