@extends('layouts.app')

@section('content')
    invest.show template
@endsection