@extends('layouts.app')

@section('content')
    invest.edit template
@endsection