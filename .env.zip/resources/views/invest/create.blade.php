@extends('layouts.app')

@section('content')
    invest.create template
@endsection