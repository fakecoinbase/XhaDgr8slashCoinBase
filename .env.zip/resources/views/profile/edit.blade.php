@extends('layouts.app')

@section('content')
    profile.edit template
@endsection