@extends('layouts.app')

@section('content')
    profile.create template
@endsection