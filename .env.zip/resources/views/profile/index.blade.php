@extends('layouts.app')

@section('content')
    profile.index template
@endsection