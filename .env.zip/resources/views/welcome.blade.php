@extends('layouts.app')

@section('content')
<div class="jumbotron position-relative overflow-hidden">
  <video playsinline="playsinline" autoplay="true" muted="muted" loop="loop">
    <source src="{{asset('storage/sa/videoplayback.mp4')}}" type="video/mp4">
  </video>
    <div class="img-overlay">
        <div class="container my-5 position-relative" style="z-index: 2222">
            <div class="w-md-50 w-75 text-white">
                <h1 class="display-4 font-weight-bold">Crypto Marcket Passive Income For Everyone.</h1>
                <h3 class="">
                    Today the company offers you very favorable and flexible terms of participation. Depending on the amount
                    of your deposit and the term of the selected investment period, you will receive a guaranteed income the
                    next day
                </h3>
                <div class="row mt-4">
                    <div class="col">
                        <a href="/" style="height: 3rem" class="btn btn-light shadow container">
                            <p class="m-0 font-weight-bold mt-1 text-primary">Get Started Now</p>
                        </a>
                    </div>
                    <div class="col">
                        <a href="/" style="height: 3rem" class="btn btn-outline-light shadow container">
                            <p class="m-0 font-weight-bold mt-1 text-primary">Contact With Us</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="container my-5 py-5">
    <div class="row">
        <div class="col-md-6">
            <h1 class="font-weight-bold text-dark">
                Invest with the world-class experienced and professional traders.
            </h1>
            <h4 class="text-muted" style="line-height: 2rem">
                Crypto Zilla is a tight-knit group of true enthusiasts of investment business and private finance
                management: experienced traders at cryptocurrency and traditional Forex exchanges, specialists in the
                initial token offering, venture specialists, as well as a large intellectual and analytical department
                of modern economic technologies. Having combined the accumulated financial experience, we created a
                truly convenient and safe space, where any User can easily invest and earn, regardless of their
                experience in investments.
            </h4>
            <div class="container mt-3 p-0">
                <a href="/" style="height: 3rem" class="btn pt-2 bg-primary shadow">
                    <p class="m-0 font-weight-bold mt-1 text-white">Get Started Now</p>
                </a>
            </div>
        </div>
        <div class="col-md-6">
            <img src="{{ asset('storage/sa/working.png') }}" class="img-fluid" alt="">
        </div>
    </div>
</section>

<section class="container my-5">
    <div class="row">
        <div class="col-md-7">
            <h1 class="font-weight-bold text-dark">
                How it works ?
            </h1>
            <p class="text-muted" style="line-height: 1.6em">
                Investments are easy and affordable for everyone with Crypto Zilla. We have developed an online platform
                for receiving investments, which will allow participants from all over the world to join the highly
                profitable earnings. It is only necessary to have an amount for investments and a desire to receive a
                passive and stable income. You are not required to have experience, knowledge of the specifics of
                exchange transactions and experience in investments - earning with our company will be completely
                passive for you and will not require any additional efforts.
                <br><br>
                All operations between the company and investors are carried out through the investment site, thus you
                only need to sign up. After reviewing our investment proposal, select the optimal rate and top up your
                account with the required amount. As soon as funds appear on your balance sheet, your deposit will begin
                its work and will make a profit in accordance with the terms of marketing. Additional actions are not
                required, and a client will be able to withdraw the profits to his wallet at any time. Join the number
                of successful investors of the company right now and get the opportunity to get financial freedom and
                your wealthy future!
            </p>
            <div class="row pl-0 mt-4">
                <div class='col-md-4'>
                    <a href="/" style="height: 3rem" class="btn pt-2 container bg-primary shadow">
                        <p class="m-0 font-weight-bold mt-1 text-white">Start Now</p>
                    </a>
                </div>
                <div class='col-md-6'>
                    <a href="/" style="height: 3rem" class="btn mt-3 mt-md-0 container btn-outline-primary shadow">
                    <p class="m-0 font-weight-bold mt-1">Investment Plans</p>
                </a></div>
            </div>
        </div>
        <div class="col-md-5">
            <img src="{{ asset('storage/sa/income.png') }}" class="img-fluid" alt="">
        </div>
    </div>
</section>

<section class="container py-5">
    <h1 class="text-center font-weight-bold">Investment plans</h1>
    <h3 class="text-muted mt-2 text-center">
        Earn up to 9.3% profit daily. The larger the amount of your investment, the more favorable conditions we use to
        transfer profits to your deposit.
    </h3>
    <div class="container mt-5">
        <div class="pt-5 pb-4 px-5 grad position-relative">
            <div class="position-absolute" style="background-size: cover;top: 0; bottom: 0; left: 0; right: 0;
            background-repeat: no-repeat;background-position: top-left;
            background-image: url({{ asset('storage/sa/offer-bg.png') }})"></div>
            <div class="row">
                <div class="col-md-10">
                    <h4 class="font-weight-bold text-white">
                        5% First Deposit Bonus
                    </h4>
                    <h5 class="text-white">
                        + 5% bonus to the amount of replenishment on the first deposit
                    </h5>
                </div>
                <div class="col-md-2">
                    <a href="/" class="btn px-4 btn-lg rounded-sm btn-light">
                        <p class="m-0 text-primary">Get Offers</p>
                    </a>
                </div>
            </div>
        </div>
        <div class="row mt-3 text-center">

            <div class="col-md-6">
                <div class="card p-0 mb-4 shadow">
                    <div class="card-header grad">
                        <h4 class="my-0 text-white font-weight-normal">PLan 1</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">Daily Rate = 1.50%</h1>
                        <div class="row">
                            <div class="col-6">
                                <h4 class="text-left">
                                    <ul class="list-unstyled mt-3 mb-4">
                                        <li class="mb-3">Total ROI :</li>
                                        <li class="mb-3">DAILY PROFIT :</li>
                                        <li class="mb-3">WITHDRAW FUNDS :</li>
                                        <li>AMOUNT :</li>
                                    </ul>
                                </h4>
                            </div>
                            <div class="col-6">
                                <h4 class="text-right">
                                    <ul class="list-unstyled mt-3 mb-4">
                                        <li>135.00% <small class="text-muted">for 90 Days</small></li>
                                        <li><div class="alert alert-success p-0 text-success">at 00:01 on the server time</div></li>
                                        <li><div class="alert alert-success p-0 text-success">Automatically</div></li>
                                        <li>
                                            <strong class="text-primary">$10 - $20</strong><br><small class="text-muted">period - <span class="alert p-0 alert-primary text-primary">90 days</span></small></li>
                                    </ul>
                                </h4>
                            </div>
                        </div>
                        <button type="button" class="btn shadow btn-lg btn-block rounded-sm text-white bg-primary">Invested</button>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card p-0 mb-4 shadow">
                    <div class="card-header grad">
                        <h4 class="my-0 text-white font-weight-normal">PLan 2</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">Daily Rate = 1.50%</h1>
                        <div class="row">
                            <div class="col-6">
                                <h4 class="text-left">
                                    <ul class="list-unstyled mt-3 mb-4">
                                        <li class="mb-3">Total ROI :</li>
                                        <li class="mb-3">DAILY PROFIT :</li>
                                        <li class="mb-3">WITHDRAW FUNDS :</li>
                                        <li>AMOUNT :</li>
                                    </ul>
                                </h4>
                            </div>
                            <div class="col-6">
                                <h4 class="text-right">
                                    <ul class="list-unstyled mt-3 mb-4">
                                        <li>135.00% <small class="text-muted">for 90 Days</small></li>
                                        <li><div class="alert alert-success p-0 text-success">at 00:01 on the server time</div></li>
                                        <li><div class="alert alert-success p-0 text-success">Automatically</div></li>
                                        <li>
                                            <strong class="text-primary">$10 - $20</strong><br><small class="text-muted">period - <span class="alert p-0 alert-primary text-primary">90 days</span></small></li>
                                    </ul>
                                </h4>
                            </div>
                        </div>
                        <button type="button" class="btn shadow btn-lg btn-block rounded-sm text-white bg-primary">Invested</button>
                    </div>
                </div>
            </div>

            <div class="col-12">

                <h1 class="text-center font-weight-bold">Shares plans</h1>
                <h3 class="text-muted mt-2 text-center">
                    Earn up to 9.3% profit daily. The larger the amount of your investment, the more favorable conditions we use to
                    transfer profits to your deposit.
                </h3>

            </div>

            <div class="col-12">
                <div class="card p-0 mb-4 shadow">
                    <div class="card-header grad">
                        <h4 class="my-0 text-white font-weight-normal">Shares Plan</h4>
                    </div>
                    <div class="card-body">
                        <h1 class="card-title pricing-card-title">Daily Rate = 1.50%</h1>
                        <div class="row">
                            <div class="col-6">
                                <h4 class="text-left">
                                    <ul class="list-unstyled mt-3 mb-4">
                                        <li class="mb-3">Total ROI :</li>
                                        <li class="mb-3">DAILY PROFIT :</li>
                                        <li class="mb-3">WITHDRAW FUNDS :</li>
                                        <li>AMOUNT :</li>
                                    </ul>
                                </h4>
                            </div>
                            <div class="col-6">
                                <h4 class="text-right">
                                    <ul class="list-unstyled mt-3 mb-4">
                                        <li>135.00% <small class="text-muted">for 90 Days</small></li>
                                        <li><div class="alert alert-success p-0 text-success">at 00:01 on the server time</div></li>
                                        <li><div class="alert alert-success p-0 text-success">Automatically</div></li>
                                        <li>
                                            <strong class="text-primary">$10 - $20</strong><br><small class="text-muted">period - <span class="alert p-0 alert-primary text-primary">90 days</span></small></li>
                                    </ul>
                                </h4>
                            </div>
                        </div>
                        <button type="button" class="btn shadow btn-lg btn-block rounded-sm text-white bg-primary">Invested</button>
                    </div>
                </div>
            </div>

        </div>

        </section>
<section class="container-fluid py-5" style="background-color: #F5F5F5">
    <div class="container py-5 my-5">
        <h1 class="text-center dispaly-3 font-weight-bold">Privileges of working with us</h1>
        <h2 class="text-muted text-center">Why is it worth cooperating with our company?</h2>

        <div class="row mt-5">
            <div class="col-md-6">
                <div class="row mb-3">
                    <div class="col-2">
                        <img src="{{ asset('storage/sa/search.svg') }}" width="100%" height="auto"
                            alt="" loading="lazy">
                    </div>
                    <div class="col-10">
                        <h5 class="mb-2 font-weight-bold">BEST CONDITIONS FOR OUR CUSTOMERS</h5>
                        <p class="font-weight-bold text-muted">
                            With Crypto Zilla you get a high percentage, flexible conditions for cooperation and no
                            risk, thanks to the diversification of the company's funds.</p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <img src="{{ asset('storage/sa/search.svg') }}" width="100%" height="auto"
                            alt="" loading="lazy">
                    </div>
                    <div class="col-10">
                        <h5 class="mb-2 font-weight-bold">
                            BEST SERVICE - FOR YOU
                        </h5>
                        <p class="font-weight-bold text-muted">
                            With our company you can be sure of the best service! Your investments will immediately
                            begin to work, and all interest will be charged quickly and on time.
                        </p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <img src="{{ asset('storage/sa/search.svg') }}" width="100%" height="auto"
                            alt="" loading="lazy">
                    </div>
                    <div class="col-10">
                        <h5 class="mb-2 font-weight-bold">24/7 SUPPORT</h5>
                        <p class="font-weight-bold text-muted">
                            We do our best to protect clients' funds and guarantee 100% security of all personal
                            information, thanks to the modern systems of data protection.
                        </p>
                    </div>
                </div>
            </div>



            <div class="col-md-6">
                <div class="row mb-3">
                    <div class="col-2">
                        <img src="{{ asset('storage/sa/search.svg') }}" width="100%" height="auto"
                            alt="" loading="lazy">
                    </div>
                    <div class="col-10">
                        <h5 class="mb-2 font-weight-bold">USER-FRIENDLY INTERFACE</h5>
                        <p class="font-weight-bold text-muted">
                            The company provides its clients with a user-friendly interface. The personal area is simple
                            and clear, basic information and buttons are placed on the main page.
                        </p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <img src="{{ asset('storage/sa/search.svg') }}" width="100%" height="auto"
                            alt="" loading="lazy">
                    </div>
                    <div class="col-10">
                        <h5 class="mb-2 font-weight-bold">
                            DATA SECURITY
                        </h5>
                        <p class="font-weight-bold text-muted">
                            Our technicians. Support will solve your problem at any time of the day. Use the convenient
                            way to communicate.
                        </p>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-2">
                        <img src="{{ asset('storage/sa/search.svg') }}" width="100%" height="auto"
                            alt="" loading="lazy">
                    </div>
                    <div class="col-10">
                        <h5 class="mb-2 font-weight-bold">STABLE INCOME</h5>
                        <p class="font-weight-bold text-muted">
                            We are ready to pay good money as interest accruals to all interested clients for
                            participating in cryptozilla.world, considering this as amicable, mutually beneficial
                            process of cooperation.
                        </p>
                    </div>
                </div>
            </div>

        </div>


    </div>
</section>

<section class="container py-5">
    <h1 class="text-center dispaly-3 font-weight-bold">Recent deposits and withdrawals</h1>
    <h3 class="text-muted text-center">List of 10 deposits and 10 withdrawals</h3>

    <div class="row mt-5">
        <div class="col-md-6">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">PARTNER ID:</th>
                        <th scope="col">DEPOSIT AMOUNT:</th>
                        <th scope="col">DEPOSIT TIME:</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-6">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">PARTNER ID:</th>
                        <th scope="col">DEPOSIT AMOUNT:</th>
                        <th scope="col">DEPOSIT TIME:</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                    <tr class="border-bottom">
                        <td>
                            <img src="{{ asset('storage/sa/search.svg') }}" width="100%"
                                height="auto" alt="" loading="lazy">
                        </td>
                        <td>
                            <h5 class="m-0">7D****A5</h5>
                        </td>
                        <td>
                            <h5 class="m-0">$20</h5>
                        </td>
                        <td>
                            <h5 class="m-0">1 minute ago</h5>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

</section>

@endsection
